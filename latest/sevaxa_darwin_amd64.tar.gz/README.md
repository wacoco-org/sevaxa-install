# sevaxa-admin

## Installation

# Installation

```bash
curl -sSfL https://raw.githubusercontent.com/wacoco-org/sevaxa-admin/main/install.sh | sh
```

```go
brew install go
```

## Packages

```bash
sevaxa-admin
go mod init github.com/wacoco-org/sevaxa-admin
go install github.com/spf13/cobra-cli@latest
cobra-cli init --pkg-name github.com/wacoco-org/sevaxa-admin
```



